# ************************************************************
# Sequel Pro SQL dump
# Version 4004
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.1.44)
# Database: ssl_final
# Generation Time: 2013-05-01 23:49:54 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table translations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `translations`;

CREATE TABLE `translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(255) DEFAULT '',
  `transWord` varchar(255) DEFAULT '',
  `definition` text,
  `transDefinition` text,
  `transLanguage` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `translations` WRITE;
/*!40000 ALTER TABLE `translations` DISABLE KEYS */;

INSERT INTO `translations` (`id`, `word`, `transWord`, `definition`, `transDefinition`, `transLanguage`)
VALUES
	(1,'golf','golf','ball game','Jeu jou&eacute; sur un grand terrain ouvert, dont le but est de frapper une balle en aussi peu de coup que possible afin de la mettre dans un trou parmi 18.','fra'),
	(6,'basketball','basket','Sport, nel quale due squadre, formate da cinque giocatori ognuna, cercano di tirare una palla dentro un canestro.','A sport in which two opposing teams of five players strive to throw a ball through a hoop.','it'),
	(11,'baseball','balle de baseball','ball used in baseball-game',NULL,'fra'),
	(12,'baseball','baseball','ballgame','A bat-and-ball sport played between two teams usually of nine players each.','it'),
	(13,'basketball','basket','Sport dans lequel s&#39;opposent deux &eacute;quipes de cinq joueurs qui essaient de mettre la balle dans un panier.','A sport in which two opposing teams of five players strive to throw a ball through a hoop.','fra');

/*!40000 ALTER TABLE `translations` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
