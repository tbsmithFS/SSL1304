<?php

if(empty($_GET['controller'])) {
	$con = 'home';
}else{
	$con = $_GET['controller'];
}

if($con == 'home'){
	include('controller/controller_home.php');
	$controller = new Home();
	$controller->get($_GET);
}else if($con == 'user'){
	include('controller/controller_user.php');
	$controller = new User();
	$controller->get($_GET);
}else{
	echo "Didn't recognize the contoller" . $con;
}

?>