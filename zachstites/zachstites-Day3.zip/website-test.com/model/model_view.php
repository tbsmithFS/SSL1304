<?php 

class View {

	function printHeader() {
		header('Content-type: text/html');
	}

	function getView($file='', $data='') {
		$fullPath = "/Users/zacharystites/Sites/website-test.com/view/$file.php";
		if(preg_match("/\w/", $file) && file_exists($fullPath)) {
			include($fullPath);
		}
	}

}

?>