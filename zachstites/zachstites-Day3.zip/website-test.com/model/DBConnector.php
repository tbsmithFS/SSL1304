<?php 

class DBConnector {
	function connect() {
		$host = '127.0.0.1';
		$user = 'root';
		$pass = '';
		$port = '8889';
		$dbname = 'ssl_php';
		return new PDO("mysql:host=$host;port=$port;dbname=$dbname", $user, $pass);
	}
}

?>