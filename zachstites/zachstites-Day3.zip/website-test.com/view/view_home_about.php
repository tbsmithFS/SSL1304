<div id="content">
	<div class="content_inner">
		<?php echo $data{'home_about'} ?>
	</div>
</div>