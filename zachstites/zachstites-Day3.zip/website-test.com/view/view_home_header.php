<!doctype html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="/style/main.css">
	<title>PHP WEBSITE | built using php</title>
</head>
<body>
	<div class="large_wrapper">
		<header>
			<h1 class="logo">PHP WEBSITE</h1>
		</header>
		<div class="clearfix"></div>
		<div class="sidebar">
			<ul>
				<a href="/home/home"><li>Homepage</li></a>
				<a href="/home/about"><li>About Us</li></a>
				<a href="/home/signup"><li>Sign Up</li></a>
				<a href="/home/login"><li>Log In</li></a>
			</ul>
		</div>