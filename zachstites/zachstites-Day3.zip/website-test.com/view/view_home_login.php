<div id="content">
	<div class="content_inner">
		<?php echo $data{'login_form'} ?>
	</div>
</div>