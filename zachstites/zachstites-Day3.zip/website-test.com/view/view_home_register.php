<div id="content">
	<div class="content_inner">
		<div class="form_wrap">
			<?php 
				include 'view/helpers/form_builder.php';

					$form = new FormBuilder($data, $form_data);
					$form->formHeader('/user/perform_register');
					$form->textInput('name');
					$form->textInput('email');
					$form->textInput('verifyemail');
					$form->textInput('password', true);
					$form->radio('rating', array('1', '2', '3', '4'));
					$form->textInput('favNumber');
					$form->submit();
					$form->formCloser();
			?>
		</div>
	</div>
</div>