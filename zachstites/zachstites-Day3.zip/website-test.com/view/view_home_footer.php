<div class="clearfix"></div>
<div id="footer">

</div>