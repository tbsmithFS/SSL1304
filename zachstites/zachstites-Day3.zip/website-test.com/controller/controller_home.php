<?php
	
	require_once 'model/model_view.php';

	class Home {
		function get($pairs, $data='') {
			if(empty($pairs['action'])) {
				$action = 'home';
			}else {
				$action = $pairs['action'];
			}

			$data = array('main_content'=>'<h2>Welcome to my homepage</h2>
			<p>Contrary to popular belief, Lorem Ipsum is not simply random text. 
			It has roots in a piece of classical Latin literature from 45 BC, making 
			it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney 
			College in Virginia, looked up one of the more obscure Latin words, consectetur, 
			from a Lorem Ipsum passage, and going through the cites of the word in classical 
			literature, discovered the undoubtable source. Lorem Ipsum comes from sections 
			1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) 
			by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very 
			popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", 
			comes from a line in section 1.10.32.

			The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those 
			interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero 
			are also reproduced in their exact original form, accompanied by English versions from the 
			1914 translation by H. Rackham.</p>');

			$view_model = new View();
			if($action == 'home'){
				$this->getUserHome($data);
			}else if($action == 'about'){
				$this->getAbout();
			}else if($action == 'signup'){
				$this->getRegisterPage();
			}else if($action == 'login'){
				$this->getLoginPage();
			}
		}

		function getUserHome($data){
				$view_model = new View();
				$view_model->getView('view_home_header', $data);
				$view_model->getView('view_home_body', $data);
				$view_model->getView('view_home_footer', $data);
		}

		function getAbout(){
				$view_model = new View();
				$data = array('home_about'=>'<h2>Get to know a little about us!</h2>
			<p>Contrary to popular belief, Lorem Ipsum is not simply random text. 
			It has roots in a piece of classical Latin literature from 45 BC, making 
			it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney 
			College in Virginia, looked up one of the more obscure Latin words, consectetur, 
			from a Lorem Ipsum passage, and going through the cites of the word in classical 
			literature, discovered the undoubtable source. Lorem Ipsum comes from sections 
			1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) 
			by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very 
			popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", 
			comes from a line in section 1.10.32.</p>');
				$view_model->getView('view_home_header', $data);
				$view_model->getView('view_home_about', $data);
				$view_model->getView('view_home_footer', $data);
		}

		function getRegisterPage(){
			$view_model = new View();
			$view_model->getView('view_home_header', $data);
			$view_model->getView('view_home_register', $data);
			$view_model->getView('view_home_footer', $data);
		}

		function getLoginPage(){
			$view_model = new View();
			$data = array('login_form'=>'<form id="login_form">
				<div class="login_form_row">
				<label>Username</label>
				<input type="text" name="username" class="login_input" id="login_user"/>
				</div>
				<br />
				<div class="login_form_row">
				<label id="password_label">Password</label>
				<input type="text" name="password" class="login_input" id="login_password"/>
				</div>
				<br />
				<div class="login_form_row">
				<input type="submit"/>
				</div>
				</form>');
			$view_model->getView('view_home_header', $data);
			$view_model->getView('view_home_login', $data);
			$view_model->getView('view_home_footer', $data);
		}

	}

?>