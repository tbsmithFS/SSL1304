<?php

	include_once "model/DBConnector.php";
	// include_once "model/date.php";
	// include_once "model/salt.php";
	include_once "model/model_view.php";

	class User {
		function get($pairs, $data=''){
			if(empty($pairs['action'])) {
				$action = 'show_registration';
			}else {
				$action = $pairs['action'];
			}

			$view_model = new View();
			if($action == 'show_registration'){
				$this->showRegistration();
			}else if($action == 'perform_register'){
				$validation_data = $this->performRegister($_POST);
				if($validation_data['successful'] == true) {
					$this->show_success();
				}else {
					$this->showRegistration($_POST, $validation_data);
				}
			}else{
				echo "Didn't recognize the action " . $action;
			}
		}

		function showRegistration($form_data=array(), $validation_data=array()) {
			$view_model = new View();
			$view_model->getView('view_home_header', $data);
			$view_model->getView('view_home_register', $validation_data);
			$view_model->getView('view_home_footer', $data);
		}

		function performRegister($form_data){
			require_once "view/helpers/form_validator.php";
			$form_validator = new FormValidator();
			$validation_data = $form_validator->validate($form_data);
			return $validation_data;
		}

		function show_success(){
			$view_model = new View();
			$view_model->getView('view_user_show_success', $data);
		}

	}

?>