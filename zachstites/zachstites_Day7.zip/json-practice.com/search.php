<?php 

class Search {
	function duck($text='') {
		$url = "http://api.duckduckgo.com/?q=" . urlencode($text) . "&format=json&pretty=1";

		$contents = file_get_contents($url);

		$data = json_decode($contents);

		$this->decode($data);
	}

	function decode($data) {
		foreach ($data as $d) {
			echo $d;
		}
	}
 }

?>