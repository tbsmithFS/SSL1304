<?php 

	if(empty($_GET['controller'])) {
	$con = 'home';
	}else{
		$con = $_GET['controller'];
	}

	if($con == 'home'){
		include('search.php');
		$search = new Search();
		$search->duck('golf');
	}

?>
