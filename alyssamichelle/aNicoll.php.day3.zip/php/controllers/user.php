<?php

require_once 'models/view.php';

class User {

  function get($pairs, $data = '') {

      if (empty($pairs['action'])) {
          $action = 'home';
      } else {
          $action = $pairs['action'];
      }
         
      $data = array( 'username' => 'tbsmith' );
      if ($action == 'home') {
          $this->getUserHome($data);
      } else if ($action == 'start-edit') {
          $this->startEdit($data);
      } else if ($action == 'perform-edit') {
          $this->performEdit($data);
          $this->getUserHome($data);
      } else if ($action == 'login') {
          $this->login($data);
      } else if ($action == 'register') {
          $this->register($data);
      } else if ($action == 'perform-register') {
          $this->performRegister($pairs, $data);
      } else {
          $this->getUserHome($data);
      }   
     
  }    
     

  function getUserHome($data) {
        $view_model = new View();
        $view_model->getView('header', $data);
        $view_model->getView('navbar', $data);
        $view_model->getView('user_home', $data);
        $view_model->getView('footer', $data);
  }


}
