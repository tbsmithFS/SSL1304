<!doctype html>  

<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	
	<title>Faces of Madison</title>
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="shortcut icon" href="/favicon.ico">
	<link rel="apple-touch-icon" href="/apple-touch-icon.png">
	<link rel='stylesheet' href='css/styles.css' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Cinzel+Decorative:400,700,900' rel='stylesheet' type='text/css'>
</head>

<body>
	<header>
		<div class="container">
			<h1>Her Face</h1>
			<nav>
				<ul>
					<li><a href="index.html">Madison</a></li>
					<li><a href="gallery.html">Her Face</a></li>
				</ul>
			</nav>
		</div>
	</header>
	<div class="container imagesContainer">
		<img src="assets/madi/160x120.gif" class="rotate80 gif">
		<img src="assets/madi/IMG_2112.jpg" class="rotate120">
		<img src="assets/madi/longWay1.gif" class="rotate180 gif">
		<img src="assets/madi/IMG_2035.jpg" class="rotate120">
		<img src="assets/madi/IMG_2173.jpg" class="rotate80">

		<img src="assets/madi/320x240.gif" class="rotate120 gif">
		<img src="assets/madi/IMG_2154.jpg" class="rotate80">
		<img src="assets/madi/IMG_2155.jpg" class="rotate120">
		<img src="assets/madi/IMG_2034.jpg" class="rotate50">

		<img src="assets/madi/640x480.gif" class="gif">
		<img src="assets/madi/IMG_2039.jpg" class="rotate80">
		<img src="assets/madi/IMG_2128.jpg" class="rotate120">
		<img src="assets/madi/IMG_2121.jpg" class="rotate80">

		<img src="assets/madi/160x120.gif" class="rotate120 gif">
		<img src="assets/madi/IMG_2042.jpg" class="rotate80">
		<img src="assets/madi/IMG_2133.jpg" class="rotate120">
		<img src="assets/madi/IMG_2115.jpg" class="rotate50">

		<img src="assets/madi/longWay2.gif" class="rotate180 gif">
		<img src="assets/madi/IMG_2146.jpg" class="rotate80">
		<img src="assets/madi/IMG_2046.jpg" class="rotate120">
		<img src="assets/madi/IMG_2151.jpg" class="rotate50">
		<img src="assets/madi/IMG_1993.jpg" class="rotate80">
		<img src="assets/madi/IMG_1965.jpg" class="rotate120">
	</div>
	<footer></footer>


  <!--<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>-->
  <script type="text/javascript" src="js/script.js"></script>
</body>

</html>







