<?php

	echo "PHP works";
?>
