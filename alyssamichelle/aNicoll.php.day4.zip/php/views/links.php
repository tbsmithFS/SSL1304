
    <link rel='stylesheet' href='assets/global.css' type='text/css'>
    <link rel='stylesheet' href='assets/images.css' type='text/css'>
    <link rel='stylesheet' href='assets/innerBody.css' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Cinzel+Decorative:400,700,900' rel='stylesheet' type='text/css'>