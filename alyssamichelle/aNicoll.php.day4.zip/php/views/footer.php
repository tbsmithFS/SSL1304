    <footer>
      <ul>
        <li>A for funsies project by<a href="http://www.alyssa.io">Alyssa Nicoll</a></li>
      </ul>
    </footer>