#!/usr/bin/python

import cgi
query = cgi.FieldStorage()

# from models.view import View

# view = View()
# view.print_header()

if 'page' not in query:
    page = 'home'
else:
    page = query.getvalue('page')

if page == 'home':
    from controllers.home import Home
    Home().get(query)
elif page == 'user':
    from controllers.user import User
    User().get(query)
else:
    # default
    from controllers.home import Home
    Home().get(query)