<form action="/user/perform_register" enctype="multipart/form-data" method="post" id="registerForm">
  <div class="input_row">

    <div class="input_left">Name</div>
      <div class="input_right">
        <input name="name" type="text" value="">
      </div>
    </div>

    <div class="input_row">
      <div class="input_left">Email</div>
      <div class="input_right">
        <input name="email" type="text" value="">
      </div>
    </div>

  <div class="input_row">
    <div class="input_left">Verifyemail</div>
    <div class="input_right">
    <input name="verifyemail" type="text" value="">
    </div>
  </div>

  <div class="input_row">
    <div class="input_left">Password</div>
    <div class="input_right">
    <input name="password" type="password" value=""></div>
  </div>

  <div class="input_row">
    <div class="input_left">Rating</div>
    <div class="input_right">
      1<input name="rating" type="radio" value="1">
      2<input name="rating" type="radio" value="2">
      3<input name="rating" type="radio" value="3">
      4<input name="rating" type="radio" value="4">
    </div>
  </div>

  <div class="input_row">
    <div class="input_left">FavNumber</div>
    <div class="input_right">
      <input name="favNumber" type="text" value="">
    </div>
  </div>

  <div class="input_row">
    <input type="submit">
  </div>

</form>