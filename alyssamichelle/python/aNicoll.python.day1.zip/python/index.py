#!/usr/bin/python

import cgi
query = cgi.FieldStorage()

# import settings.db
from models.view import View

view = View()
view.print_header()

if 'page' not in query:
    page = 'home'
else:
    page = query.getvalue('page')

view.get_view("header")
view.get_view(page)
view.get_view("footer")