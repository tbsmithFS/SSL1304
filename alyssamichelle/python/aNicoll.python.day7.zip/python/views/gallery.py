<div class="container imagesContainer">
	<img src="/assets/images/madi/160x120.gif" class="rotate80 gif">
	<img src="assets/images/madi/IMG_2112.jpg" class="rotate120">
	<img src="assets/images/madi/longWay1.gif" class="rotate180 gif">
	<img src="assets/images/madi/IMG_2035.jpg" class="rotate120">
	<img src="assets/images/madi/IMG_2173.jpg" class="rotate80">

	<img src="assets/images/madi/320x240.gif" class="rotate120 gif">
	<img src="assets/images/madi/IMG_2154.jpg" class="rotate80">
	<img src="assets/images/madi/IMG_2155.jpg" class="rotate120">
	<img src="assets/images/madi/IMG_2034.jpg" class="rotate50">

	<img src="assets/images/madi/640x480.gif" class="gif">
	<img src="assets/images/madi/IMG_2039.jpg" class="rotate80">
	<img src="assets/images/madi/IMG_2128.jpg" class="rotate120">
	<img src="assets/images/madi/IMG_2121.jpg" class="rotate80">

	<img src="assets/images/madi/160x120.gif" class="rotate120 gif">
	<img src="assets/images/madi/IMG_2042.jpg" class="rotate80">
	<img src="assets/images/madi/IMG_2133.jpg" class="rotate120">
	<img src="assets/images/madi/IMG_2115.jpg" class="rotate50">

	<img src="assets/images/madi/longWay2.gif" class="rotate180 gif">
	<img src="assets/images/madi/IMG_2146.jpg" class="rotate80">
	<img src="assets/images/madi/IMG_2046.jpg" class="rotate120">
	<img src="assets/images/madi/IMG_2151.jpg" class="rotate50">
	<img src="assets/images/madi/IMG_1993.jpg" class="rotate80">
	<img src="assets/images/madi/IMG_1965.jpg" class="rotate120">
</div>