<div class="container mainBody">
  <p class="content">
    This website is dedicated to my little sister&rsquo;s face. 
    I love her dearly, and she loves her face. So what better way 
    to exalt her than to give her face a gift? 
    <span class="emp">Love you little sis. -a.n.</span>
  </p>
  <form action="/word_service/fnsearch" enctype="multipart/form-data" method="GET">
    <h2>Search Users</h2>
    <label for="firstname">Firstname</label>
    <input name="firstname" placeholder="firstname" id="firstname" value="bob">
    <input type="submit" value="submit">
  </form>  

  <form action="/word_service/duck" enctype="multipart/form-data" method="GET">
    <h2>Search Duck Duck Go</h2>
    <label for="text">Keyword</label>
    <input name="text" placeholder="text" id="text" value="monkey">
    <input type="submit" value="submit">
  </form>
</div>
