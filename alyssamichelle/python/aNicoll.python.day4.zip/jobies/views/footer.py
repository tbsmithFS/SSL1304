<footer>
  <ul>
    <li>A project by
      <a href="https://twitter.com/zachstites">Zachary Stites</a>
      <a href="http://www.alyssa.io">Alyssa Nicoll</a>
    </li>
  </ul>
</footer>
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
# <script src="main.js" type="text/javascript"></script>
</body>
</html>