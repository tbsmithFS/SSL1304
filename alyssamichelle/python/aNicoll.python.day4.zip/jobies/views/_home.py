<div class="container mainBody">
  <form action="/search_service/search" enctype="multipart/form-data" method="GET">
    <input name="searchTerm" placeholder="Find Your Dream Job Today" id="searchTerm" value="Web Developer">
    <input type="submit" value="Find It!">
  </form>
</div>