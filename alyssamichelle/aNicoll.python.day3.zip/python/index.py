#!/usr/bin/python

print "Content-type: text/html\n\n"

print "Python works"
