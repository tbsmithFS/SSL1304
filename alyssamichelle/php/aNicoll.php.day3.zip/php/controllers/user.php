<?php

class User {

    function show_register_form($form_data=array(), $validation_data=array()) {
        require_once "views/register.php";
    }

    function perform_register($form_data) {
        require_once "views/helpers/form_validator.php";
        $form_validator = new FormValidator();
        $validation_data = $form_validator->validate($form_data);
        return $validation_data;
    }

    function show_success_page() {
        require_once "views/register_success.php";
    }

}

?>