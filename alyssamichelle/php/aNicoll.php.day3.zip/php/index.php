<?php 
	include("settings/db.php");
	include("models/view.php");

	$view = new View();
	$view->printHeader();

	$view->getView("header", $data);

	$query = $_GET;
	if (empty($query['page'])) {
	    $page = 'home';
	} else {
			$page = $query['page'];
	}
	
if ($page == 'user') {
  include "controllers/user.php";
  $user = new User();

  if (empty($query['action'])) {
      $action = 'show_register_form';
  } else {
      $action = $query['action'];
  }

  if ($action == 'show_register_form') {
  	$user->show_register_form();
  	// $page = 'register';

  } else if ($action == 'perform_register') {
      $validation_data = $user->perform_register($_POST);
      if ($validation_data['successful'] == true) {
          $user->show_success_page();
      } else {
          $user->show_register_form($_POST, $validation_data);
      }
  } else {
      echo "Didn't recognize the action " . $action;
  }
}else{
    echo "Didn't recognize the page " . $page;
}
	$view->getView($page, $data);
	$view->getView("footer", $data);

?>