<?php

echo "REGISTRATION SUCCESS!!!!";

?>
