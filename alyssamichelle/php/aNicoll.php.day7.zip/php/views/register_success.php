<?php
echo '<div class="styleMyEcho">';
echo "REGISTRATION SUCCESS!!!!";
echo '</div>';

?>
