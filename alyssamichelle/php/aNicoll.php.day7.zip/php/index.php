<?php 

  session_start();
	include("settings/db.php");
	include("models/view.php");
	include("controllers/home.php");
  include("controllers/word_service.php");

	$view = new View();
	$view->printHeader();
  $g = $_GET;
  $p = $_POST;


  $home = new Home();
	$view->getView("header", $data);

  // if no page in g do default
  // else set page variable
	// if (empty($g['page'])) {
	//     $page = 'home';
	// } else {
	// 	$page = $g['page'];
	// }

  $page = empty($g['page']) ? 'home' : $g['page'];
  $action = empty($g['action']) ? 'encode' : $g['action'];
  $ws = new WordService();

  if ($page == 'home') {
    $home = new Home();
    $home->dispatch($action);
    echo " " . $action . ' inside index if == home';
  }else if ($page == 'user') {
    include 'controllers/user.php';
    $user = new User();
    $user->dispatch($action);

    // if (empty($g['action'])) {
    //     $action = 'show_register_form';
    // } else {
    //     $action = $g['action'];
    // }

    if($action == 'show_register_form'){
    	$user->show_register_form();
    }else if ($action == 'perform_register'){
      $validation_data = $user->perform_register($_POST);
      if($validation_data['successful'] == true){
        $user->show_success_page();
      }else{
        $user->show_register_form($_POST, $validation_data);
      }
    }else{
        echo "Didn't recognize the action " . $action;
    }
  }else if($page == 'word_service'){
    if($action == 'fnsearch'){
      if(!empty($p['firstname'])){
        $firstname = $p['firstname'];
        echo $ws->fnsearch($firstname);
      }else{
        echo "Nothing to search for.";
      }
    }else if($action == 'duck'){
      echo $ws->duck($p['text']);
    }else{
        echo "Didn't recognize the action " . $action;
    }
  }else{
      echo "Didn't recognize the page " . $page;
  }
	$view->getView($page, $data);
	$view->getView("footer", $data);

?>
