<?php
  // include protector in files where you want to keep them secret
  include_once "models/view.php";
  $view = new View();

  echo "session is [";
  var_dump($_SESSION);
  echo "]";

  if(
	empty($_SESSION) || 
	empty($_SESSION['isLoggedIn']) || 
	$_SESSION['isLoggedIn'] != True){

    $view->getView('loggedOutHeader');
    $view->getView('home');
    $view->getView('footer');
    exit();
  }else if ($_SESSION['isLoggedIn'] == True) {
      // Is Logged In then do nothing
  }
?>
