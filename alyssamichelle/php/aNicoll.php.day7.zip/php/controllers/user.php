<?php

// include_once '../models/dbconnector.php';
// include_once '../models/date.php';
// include_once '../models/salt.php';
include_once '../models/view.php';

$p = $_POST;
$sessionLength = 288000; // minutes for 200 days
// $connector = new DBConnector();
// $db = $connector->connect();

class User {
    
    function show_register_form($form_data=array(), $validation_data=array()) {
        require_once "views/register.php";
    }

    function perform_register($form_data) {
        require_once "views/helpers/form_validator.php";
        $form_validator = new FormValidator();
        $validation_data = $form_validator->validate($form_data);
        return $validation_data;
    }

    function show_success_page() {
        require_once "views/register_success.php";
    }

    function dispatch($action='') {

        if ($action == 'register') {            
            // validate form info > make sure the user doesn't already exist
            $this->addUser($p['username'], $p['email'], $p['password']);
            $this->login($p['username'], $p['password']);        

            $view = new View();
            $view->getView('header');
            $view->getView('home');
            $view->getView('footer');
        } else if ($action == 'logIn') {
            // validate form info
            $this->login($p['username'], $p['password']);        
        } else if ($action == 'logOut') {
            $this->logout();
        }
    }

    function addUser($username='', $email='', $password='') {
        // insert user
        $stmnt = $db->prepare("insert into user (username, email)
            values (:username, :email)");
        $stmnt->execute(array(
            ':username' => $username,
            ':email' => $email));
        
        // get userId
        $userId = $db->lastInsertId(); 

        // create salt
        $salter = new Salt();
        $salt = $salter->getRandomString(20);

        // insert salt
        $stmnt = $db->prepare("insert into salt (userId, salt)
            values (:userId, :salt)");
        $stmnt->execute(array(
            ':userId' => $userId,
            ':salt' => $salt));

        // insert hashed password
        $stmnt = $db->prepare("update user set passwordHash = :passwordHash where userId = :userId");
        $stmnt->execute(array(
            ':passwordHash' => md5($password.$salt),
            ':userId' => $userId));
    }

    function login($username='', $password='') {
        // get userId
        $userId = $this->getUserId($username);

        if (empty($userId)) {
            $data['username']['msg'] = "No such username";
            $v = new View();
            $v->getView("header");
            $v->getView("login", $data);
            $v->getView("footer");
            exit();
        }

        // get user's salt
        $salter = new Salt();
        $salt = $salter->getUserSalt($userId);

        // get hashed password
        $hashedPassword = $this->getUserPassword($this->getUserId($username));

        // create this hash
        $thisHash = md5($password . $salt);

        #echo "hashed: $hashedPassword<br/>";
        #echo "this: $thisHash<br/>";

        $view = new View();
        if ($hashedPassword == $thisHash) {
            $_SESSION['isLoggedIn'] = True;
            $view->getView('header');
            $view->getView('loggedIn');
            exit();
        } else {
            $data['password']['msg'] = "Bad Password";
            $view->getView('header');
            $view->getView('login', $data);
        }
        $view->getView('footer');
    }

    function logout() {
        session_destroy();
        $_SESSION['isLoggedIn'] = False;
        $view = new View();
        echo 'LOGOUT IS HAPPENING';
        $view->getView('loggedOutHeader');
        $view->getView('home');
        $view->getView('footer');
    }

    function getUserPassword($userId) {
        $connector = new DBConnector();
        $db = $connector->connect();

        $stmnt = $db->prepare("select passwordHash from user 
            where userId = :userId");
        $stmnt->execute(array(':userId'=>$userId));
        $rows = $stmnt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            return $row['passwordHash'];
        }
    }

    function getUserId($username='') {
        $connector = new DBConnector();
        $db = $connector->connect();

        $stmnt = $db->prepare("select userId from user where username = :username");
        $stmnt->execute(array(':username'=>$username));
        $rows = $stmnt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            return $row['userId'];
        }
    }

    function receiveRegisterForm($form=array()) {
        // do form verification here
        $this->addUser($form['username'], $form['email'], $form['password']);
        $this->login($form['username'], $form['password']);
    }

}

?>