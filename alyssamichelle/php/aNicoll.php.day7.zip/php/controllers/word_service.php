<?php

include "models/DBConnector.php";

class WordService {

    var $db;

    function __construct() {
        $dbc = new DBConnector();
        $this->db = $dbc->connect();
    }

    function fnsearch($fn) {
        $sql = "SELECT count(firstname) AS count, firstname, lastname
                FROM million
                WHERE firstname LIKE ?
                GROUP BY lastname
                LIMIT 10;";
        $q = $this->db->prepare($sql);
        $w = $this->db->prepare($sql);
        $w->execute(array($fn));
        $q->execute(array($fn));

        echo "<h2>JSONs For You!</h2>";

        echo "<div class='wordServiceData json'>";
        echo json_encode($q->fetchAll());
        echo "</div>";

        echo "<h2>First Name Search Results</h2>";

        echo "<div class='wordServiceData'>";
        foreach($w->fetchAll() as $row){
            echo '<p>';
            echo $row['count']. " ";
            echo $row['firstname'] . " ";
            echo $row['lastname'] . "'s";
            echo '</p>';        
        }
        echo "</div>";
    }

    function duck($text='default') {

        $url = "http://api.duckduckgo.com/?q=" 
            . urlencode($text)
            . "&format=json&pretty=1";

        $contents = file_get_contents($url);

        $data = json_decode($contents);

        echo "<h2>Duck Duck Go Search Results</h2>";
        echo "<div class='wordServiceData'>";
        var_dump($data);
        echo "</div>";
    }

}

?>
