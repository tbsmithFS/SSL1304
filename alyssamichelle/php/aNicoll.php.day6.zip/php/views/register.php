<html>
<head>
<link href="/css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
    <h2>Register</h2>

    <?php

      include 'views/helpers/form_builder.php';

      $form = new FormBuilder($validation_data, $form_data);
      $form->formHeader('/user/addUser');
      $form->textInput('name');
      $form->textInput('email');
      $form->textInput('verifyemail');
      $form->textInput('password', true);
      $form->radio('rating', array('1', '2', '3', '4'));
      $form->textInput('favNumber');
      $form->submit();
      $form->formCloser();

    ?>

</body>
</html>
