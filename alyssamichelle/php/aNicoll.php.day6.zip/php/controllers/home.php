<?php
  include_once "models/view.php";

  class Home {
    function dispatch($action) {
      if ($action){ 
          $view = new View();
          $view->getView($action);
          echo $action . ' inside of controllers/home.php';
      } else {
		echo 'Did not recognize action' . $action;
	}
    }
  }
?>