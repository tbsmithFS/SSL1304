<div class="section page">
  <h1>Contact</h1>
</div>