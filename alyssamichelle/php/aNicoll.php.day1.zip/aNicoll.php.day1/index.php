<?php 
	include("settings/db.php");
	include("models/view.php");

	$view = new View();
	$view->printHeader();

	$view->getView("header", $data);

	$query = $_GET;
	if (empty($query['page'])) {
	    $page = 'home';
	} else {
			$page = $query['page'];
	}
	$view->getView($page, $data);
	$view->getView("footer", $data);

?>