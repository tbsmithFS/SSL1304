#!/usr/bin/python

dbConfig = {

	'host'		:	"127.0.0.1",
	'username'	:	"tbsmith",
	'password'	:	"pass",
	'database'	:	"SSL1304tbsmithPython"
}