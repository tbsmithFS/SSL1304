#!/usr/bin/python

import json
import urllib2
from models.view import View
from models.DBConnector import DBConnector
view_model = View()


class WordService():
    definition = "hi"
    trans_word = "hi"
    trans_definition ="hi"
    view_model.get_view('header')
    view_model.get_view('home')

    def search(self, fromLang="eng",toLang="fra", text="default"):
        response = urllib2.urlopen("http://glosbe.com/gapi/translate?from=" + str(fromLang) + "&dest="+ str(toLang) + "&format=json&phrase=" + str(text) + "&pretty=true")
        resp = response.read()
        gotJson = json.loads(resp)

        print '<div class="sectionHeader"> From English To :'
        print gotJson['dest'] + '</br>' + 'Translating  :' + gotJson['phrase'] + '</div>'

        num = 0

        for jsonObj in gotJson['tuc']:
            num += 1
            dumb = 1
            print '<section>' 
            print '<div>' + str(num) + ' : ' + '</div>'
            # print '<div>' + jsonObj['meanings']['text'] + '</div>'

            for meanings, text in jsonObj.iteritems():   
                print meanings, text
                print '</br>'

                # while (dumb == 1) :
                #     dumb += 1
                #     definition = str(text)
                #     trans_word = "hi"
                #     trans_definition ="hi"


            print '<div>' + 'Definition' + '</div>'
            # print '<div>' + jsonObj['phrase']['text'] + '</div>'

            for phrase, text in jsonObj.iteritems():   
                print phrase, text
                print '</br>'

            print '</section>'
            return definition, trans_word, trans_definition
            print "Location: /word_service/addWord\n\n"


    def addWord(self, definition='',trans_word='', trans_definition='', toLang='', text=''):
        print 12
        db = DBConnector().get_connection()
        print 34
        sql = "INSERT INTO Dictionary (word, definition, trans_word, trans_definition, trans_language) VALUES(%(word)s, %(definition)s, %(trans_word)s, %(trans_definition)s, %(trans_language)s);"
        user_info = {
            'word': 'text',
            'definition': definition,
            'trans_word': trans_word,
            'trans_definition': trans_definition,
            'trans_language': toLang
        }
    
        cursor = db.cursor()
        print 56
        cursor.execute(sql, user_info)
        db.commit()
        cursor.close()
        db.close()
        # print "Location: /home\n\n"



