#!/usr/bin/python

import json
import urllib2
from models.view import View
from models.DBConnector import DBConnector
view_model = View()



class WordService():
    view_model.get_view('header')
    view_model.get_view('home')

    def __init__(self):
        self.definition='value is not being set by search def in WordService class' 
        self.trans_word='value is not being set by search def in WordService class'
        self.trans_definition='value is not being set by search def in WordService class'

    def search(self, fromLang="eng",toLang="fra", text="default"):
        response = urllib2.urlopen("http://glosbe.com/gapi/translate?from=" + str(fromLang) + "&dest="+ str(toLang) + "&format=json&phrase=" + str(text) + "&pretty=true")
        resp = response.read()
        gotJson = json.loads(resp)

        print '<div class="sectionHeader"> From English To :'
        print gotJson['dest'] + '</br>' + 'Translating  :' + gotJson['phrase'] + '</div>'

        num = 0

        for jsonObj in gotJson['tuc']:
            num += 1
            print '<section>' 
            print str(num) + ': '

            for key, value in jsonObj.iteritems(): 
                if key == 'phrase':
                    print '<div> Translated: '
                    print value['text']
                    print '</div>'
                    self.trans_word = value
                if key == 'meanings':
                    for array in value:
                        for key, value in array.iteritems():
                            if key == 'text':
                                print '<div> Definition: ' + str(num) + ': '
                                print value
                                print '</div>'
                                self.trans_definition = value
                                if num ==1:
                                    self.definition = value


            print '</section>'
            # return definition, trans_word, trans_definition
            # print "Location: /word_service/addWord\n\n"


    def addWord(self, toLang='', text=''):
        db = DBConnector().get_connection()
        sql = "INSERT INTO Dictionary (word, definition, trans_word, trans_definition, trans_language) VALUES(%(word)s, %(definition)s, %(trans_word)s, %(trans_definition)s, %(trans_language)s);"
        user_info = {
            'word': text,
            'definition': self.definition,
            'trans_word': self.trans_word,
            'trans_definition': self.trans_definition,
            'trans_language': toLang
        }
    
        cursor = db.cursor()
        cursor.execute(sql, user_info)
        db.commit()
        cursor.close()
        db.close()
        # print "Location: /home\n\n"



