<!doctype html>  

  <html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    
    <title>Python Final</title>
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel='stylesheet' href='/assets/global.css' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Cinzel+Decorative:400,700,900' rel='stylesheet' type='text/css'>

  </head>

  <body>
    <header>
      <div class="headerContainer">
        <h1>PYTHON FINAL</h1>
        <h2>SSL1304</h2>
        <h3>Alyssa Nicoll</h3>
        
    </header>