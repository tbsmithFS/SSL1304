<div class="container mainBody">

  <form action="/word_service/search" enctype="multipart/form-data" method="POST">
    <h2>Translate That Word!</h2>

    <label for="fromLang">From: </label>
    <select name="fromLang" autofocus>
      <option value="eng">English</option>
      <option value="deu">German</option>
      <option value="fra">French</option>
    </select>    

    <label for="toLang">To: </label>
    <select name="toLang">
      <option value="deu">German</option>
      <option value="fra">French</option>
      <option value="eng">English</option>
    </select>

    <label for="text">Translate: </label>
    <input name="text" placeholder="text" id="text" value="monkey">

    <input type="submit" value="Translate">
  </form>
</div>
