#!/usr/bin/python
print "Content-type: text/html\n\n"

import cgi
query = cgi.FieldStorage()
from controllers.word_service import WordService

ws = WordService()
definition = ''
trans_word = ''
trans_definition = ''

if 'page' in query and 'action':
    page = query.getvalue('page')
    action = query.getvalue('action')
    fromLang = query.getvalue('fromLang')
    toLang = query.getvalue('toLang')
    text = query.getvalue('text')

if action == 'search':
  ws.search(fromLang, toLang, query.getvalue('text'))
  ws.addWord(toLang, text)
