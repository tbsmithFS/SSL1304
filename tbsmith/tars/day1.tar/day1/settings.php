<?php

define("WD", "/home/www/ssl1303/tbsmith/day1");

?>

